package vscrawlpackage;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class Testingtwo {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        System.setProperty("webdriver.http.factory", "jdk-http-client");

        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:platformVersion", "11");
        caps.setCapability("appium:deviceName", "SM N970F");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appPackage", "com.vscrawl.vscrawl");
        caps.setCapability("appium:udid", "R3CM810F5TP");
        caps.setCapability("appium:uiautomator2ServerInstallTimeout", 60000);
        caps.setCapability("appium:appActivity", ".MainActivity");

        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        AndroidDriver driver = new AndroidDriver(url, caps);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement navBar = wait.until(ExpectedConditions.elementToBeClickable(By.id("android:id/navigationBarBackground")));
            navBar.click();
        } catch (Exception e) {
            System.out.println("Navigation bar not clickable or not present.");
        }

        List<WebElement> inputFields = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("android.widget.EditText")));
        WebElement emailField = inputFields.get(0);
        wait.until(ExpectedConditions.elementToBeClickable(emailField)).click();
        emailField.sendKeys("johnsmithgiles@yopmail.com");
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));

        WebElement passwordField = inputFields.get(1);
        wait.until(ExpectedConditions.elementToBeClickable(passwordField)).click();
        passwordField.sendKeys("P@ssword123");
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));

        WebElement signInBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//android.view.View[@content-desc=\"Sign in\"])[2]")));
        signInBtn.click();

        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Tab 3 of 5\"]")).click();
        driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"Sign Document\"]")).click();
        driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"Browse a document to upload\"]")).click();

        try {
            WebElement allowButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("com.android.permissioncontroller:id/permission_allow_button")));
            allowButton.click();
            System.out.println("Permission allowed.");
        } catch (Exception e) {
            System.out.println("Permission popup did not appear, or was already handled.");
        }

        WebElement fileToSelect = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//android.widget.TextView[@text='AES Multi flow Template.pdf']")));
        fileToSelect.click();

        Thread.sleep(9000);
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Next\"]")).click();
        Thread.sleep(9000);
        driver.findElement(By.xpath("//android.widget.Button[2]")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Signature\"]/android.widget.ImageView")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Save\"]")).click();
        Thread.sleep(2000);

     List<WebElement> images = driver.findElements(By.className("android.widget.ImageView"));
        System.out.println("ImageView count: " + images.size());
        for (int i = 0; i < images.size(); i++) {
            System.out.println("ImageView[" + i + "] loc: " + images.get(i).getLocation());
        }
        
  //driver.findElement(By.xpath("//android.view.View[contains(@content-desc, \"1 of\")]/android.widget.ImageView[1]")).click();

   		
   
driver.findElement(By.xpath("//android.view.View[@content-desc=\"1 of 1\"]/android.widget.ImageView")).click();

    
    



    
    
    
    
    
    
    
    
    }
}
        
   

        
        
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


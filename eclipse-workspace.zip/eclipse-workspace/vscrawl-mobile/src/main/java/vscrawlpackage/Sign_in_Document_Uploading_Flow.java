package vscrawlpackage;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Collections;

import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class Sign_in_Document_Uploading_Flow {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        System.setProperty("webdriver.http.factory", "jdk-http-client");

        // Capabilities Setup
        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:platformVersion", "11");
        caps.setCapability("appium:deviceName", "SM N970F");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appPackage", "com.vscrawl.vscrawl");
        caps.setCapability("appium:udid", "R3CM810F5TP");
        caps.setCapability("appium:uiautomator2ServerInstallTimeout", 60000);
        caps.setCapability("appium:appActivity", ".MainActivity");

        AndroidDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            // Login Flow
            WebElement emailField = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("android.widget.EditText")));
            emailField.click();
            emailField.sendKeys("johnsmithgiles@yopmail.com");
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement passwordField = driver.findElements(By.className("android.widget.EditText")).get(1);
            wait.until(ExpectedConditions.elementToBeClickable(passwordField)).click();
            passwordField.sendKeys("P@ssword123");
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement signInBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//android.view.View[@content-desc='Sign in'])[2]")));
            signInBtn.click();
            System.out.println("✅ Sign-in successfully");

            // Navigate to Dashboard (Tab 3)
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//android.widget.Button[@content-desc='Tab 3 of 5']"))).click();
            System.out.println("✅ Moved to dashboard screen");

            // Upload Document
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//android.widget.ImageView[@content-desc='Sign Document']"))).click();
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//android.widget.ImageView[@content-desc='Browse a document to upload']"))).click();

            // Handle permission if shown
            try {
                WebElement allowButton = wait.until(ExpectedConditions.elementToBeClickable(
                        By.id("com.android.permissioncontroller:id/permission_allow_button")));
                allowButton.click();
                System.out.println("Permission allowed.");
            } catch (Exception e) {
                System.out.println("Permission already granted or not required.");
            }

            // Select File
            WebElement fileToSelect = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//android.widget.TextView[@text='AES Multi flow Template.pdf']")));
            fileToSelect.click();
            System.out.println("✅ Document is uploaded successfully");

            // Click Next Button
            Thread.sleep(9000); // Wait for file to be loaded
            driver.findElement(By.xpath("//android.view.View[@content-desc='Next']")).click();
            System.out.println("✅ Successfully clicked on the next button");

            Thread.sleep(18000); // Wait for UI to stabilize

            // Add Signature
            driver.findElement(By.xpath("//android.widget.Button[2]")).click(); // Add Signature Field
            Thread.sleep(6000);
            driver.findElement(By.xpath("//android.view.View[@content-desc='Signature']/android.widget.ImageView")).click();
            Thread.sleep(6000);
            driver.findElement(By.xpath("//android.widget.Button[@content-desc='Save']")).click();
            Thread.sleep(2000);

            // Drag and Drop Signature Field
            WebElement source = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//android.view.View[contains(@content-desc,'1 of')]/android.widget.ImageView[2]")));

            WebElement target = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//android.view.View[contains(@content-desc,'1 of')]/android.widget.ImageView[2]")));

            int startX = source.getLocation().getX() + (source.getSize().getWidth() / 2);
            int startY = source.getLocation().getY() + (source.getSize().getHeight() / 2);
            int endX = target.getLocation().getX() + (target.getSize().getWidth() / 2);
            int endY = target.getLocation().getY() + (target.getSize().getHeight() / 2);

            PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
            Sequence dragAndDrop = new Sequence(finger, 1);
            dragAndDrop.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), startX, startY));
            dragAndDrop.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
            dragAndDrop.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), endX, endY));
            dragAndDrop.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
            driver.perform(Collections.singletonList(dragAndDrop));

            System.out.println("✅ Dropped the signature field on the document successfully.");

        } catch (Exception e) {
            System.err.println("❌ Test failed: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}

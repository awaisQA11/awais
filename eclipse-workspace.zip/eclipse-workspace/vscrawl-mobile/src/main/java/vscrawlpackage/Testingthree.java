package vscrawlpackage;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;

import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class Testingthree {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        System.setProperty("webdriver.http.factory", "jdk-http-client");

        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:platformVersion", "11");
        caps.setCapability("appium:deviceName", "SM N970F");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appPackage", "com.vscrawl.vscrawl");
        caps.setCapability("appium:udid", "R3CM810F5TP");
        caps.setCapability("appium:uiautomator2ServerInstallTimeout", 60000);
        caps.setCapability("appium:appActivity", ".MainActivity");

        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        AndroidDriver driver = new AndroidDriver(url, caps);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement navBar = wait.until(ExpectedConditions.elementToBeClickable(By.id("android:id/navigationBarBackground")));
            navBar.click();
        } catch (Exception e) {
            System.out.println("Navigation bar not clickable or not present.");
        }

        // Login Flow
        WebElement emailField = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("android.widget.EditText")));
        emailField.click();
        emailField.sendKeys("johnsmithgiles@yopmail.com");
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));

        WebElement passwordField = driver.findElements(By.className("android.widget.EditText")).get(1);
        wait.until(ExpectedConditions.elementToBeClickable(passwordField)).click();
        passwordField.sendKeys("P@ssword123");
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));

        WebElement signInBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//android.view.View[@content-desc=\"Sign in\"])[2]")));
        signInBtn.click();

        // Upload document
        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Tab 3 of 5\"]")).click();
        driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"Sign Document\"]")).click();
        driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"Browse a document to upload\"]")).click();

        try {
            WebElement allowButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("com.android.permissioncontroller:id/permission_allow_button")));
            allowButton.click();
            System.out.println("Permission allowed.");
        } catch (Exception e) {
            System.out.println("Permission popup did not appear or already handled.");
        }

        WebElement fileToSelect = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//android.widget.TextView[@text='AES Multi flow Template.pdf']")));
        fileToSelect.click();

        Thread.sleep(9000);
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Next\"]")).click();
        Thread.sleep(10000);
        driver.findElement(By.xpath("//android.widget.Button[2]")) .click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Signature\"]/android.widget.ImageView")) .click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Save\"]")) .click();
        Thread.sleep(2000);

        
        
     // Step 1: Locate the draggable signature element
        WebElement source = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.xpath("//android.view.View[@content-desc='1 of 1']/android.widget.ImageView[2]")));

        // Step 2: Locate the target signature field (the green box)
        WebElement target = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.xpath("//android.view.View[@content-desc='1 of 1']/android.widget.ImageView[2]")));

        // Step 3: Get source and target coordinates
        int startX = source.getLocation().getX() + (source.getSize().getWidth() / 2);
        int startY = source.getLocation().getY() + (source.getSize().getHeight() / 2);

        int endX = target.getLocation().getX() + (target.getSize().getWidth() / 2);
        int endY = target.getLocation().getY() + (target.getSize().getHeight() / 2);

        // Step 4: Drag and drop using W3C Touch Action
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence dragAndDrop = new Sequence(finger, 1);
        dragAndDrop.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), startX, startY));
        dragAndDrop.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        dragAndDrop.addAction(finger.createPointerMove(Duration.ofMillis(800), PointerInput.Origin.viewport(), endX, endY));
        dragAndDrop.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

        driver.perform(Collections.singletonList(dragAndDrop));

        System.out.println("✅ Signature dragged to the signature box.");

        String pageDesc = "1 of 1"; // Or get it dynamically from context
        int imageIndex = 2;

        String dynamicXPath = String.format("\"//android.view.View[contains(@content-desc, \\\"1 of\\\")]/android.widget.ImageView[2]\\r\\n\"\r\n"
        		+ "		+ \"\"", pageDesc, imageIndex);
        WebElement element = driver.findElement(AppiumBy.xpath(dynamicXPath));
   
        
        
        
     
    }



        
   
        
        
        
   


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    }


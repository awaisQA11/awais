package vscrawlpackage;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class SignupTest {

    static Random random = new Random();
    static String LOWER = "abcdefghijklmnopqrstuvwxyz";
    static String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static String DIGITS = "0123456789";
    static String SPECIAL = "!@#$%^&*()_+-=[]{}|;:,.<>?";

    public static String generateFullName() {
        return capitalize(generateLetters(5)) + " " + capitalize(generateLetters(6));
    }

    public static String generateLetters(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(LOWER.charAt(random.nextInt(LOWER.length())));
        }
        return sb.toString();
    }

    public static String capitalize(String text) {
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }

    public static String generateUsername() {
        String uname = generateLetters(8);
        System.out.println("Username: " + uname);
        return uname;
    }

    public static String generateEmail(String username) {
        String email = username + "@yopmail.com";
        System.out.println("Email: " + email);
        return email;
    }

    public static String generatePassword(int length) {
        StringBuilder sb = new StringBuilder();
        sb.append(LOWER.charAt(random.nextInt(LOWER.length())));
        sb.append(UPPER.charAt(random.nextInt(UPPER.length())));
        sb.append(DIGITS.charAt(random.nextInt(DIGITS.length())));
        sb.append(SPECIAL.charAt(random.nextInt(SPECIAL.length())));
        String all = LOWER + UPPER + DIGITS + SPECIAL;
        for (int i = 4; i < length; i++) {
            sb.append(all.charAt(random.nextInt(all.length())));
        }

        // Shuffle characters
        char[] chars = sb.toString().toCharArray();
        for (int i = 0; i < chars.length; i++) {
            int j = random.nextInt(chars.length);
            char temp = chars[i];
            chars[i] = chars[j];
            chars[j] = temp;
        }

        String finalPassword = new String(chars);
        System.out.println("Password: " + finalPassword);
        return finalPassword;
    }

    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        System.out.println("Starting Vscrawl signup test...");

        MutableCapabilities caps = new MutableCapabilities();
        caps.setCapability("platformName", "Android");
        caps.setCapability("appium:platformVersion", "11");
        caps.setCapability("appium:deviceName", "SM N970F");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appPackage", "com.vscrawl.vscrawl");
        caps.setCapability("appium:udid", "R3CM810F5TP");
        caps.setCapability("appium:uiautomator2ServerInstallTimeout", 60000);
        caps.setCapability("appium:appActivity", ".MainActivity");

        AndroidDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            // Click initial sign-up button
            WebElement signUp = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//android.widget.Button[@content-desc='Sign up']")));
            signUp.click();
            System.out.println("Tapped on initial 'Sign up'");

            Thread.sleep(3000); // Wait for form to load

            // Prepare input
            String fullName = generateFullName();
            String username = generateUsername();
            String email = generateEmail(username);
            String org = generateLetters(5) + random.nextInt(999);
            String password = generatePassword(10);

            // Locate all input fields
            List<WebElement> inputFields = wait.until(
                ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("android.widget.EditText")));

            // Fill each field
            WebElement fullNameField = inputFields.get(0);
            wait.until(ExpectedConditions.elementToBeClickable(fullNameField)).click();
            fullNameField.sendKeys(fullName);
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement usernameField = inputFields.get(1);
            wait.until(ExpectedConditions.elementToBeClickable(usernameField)).click();
            usernameField.sendKeys(username);
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement emailField = inputFields.get(2);
            wait.until(ExpectedConditions.elementToBeClickable(emailField)).click();
            emailField.sendKeys(email);
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement orgField = inputFields.get(3);
            wait.until(ExpectedConditions.elementToBeClickable(orgField)).click();
            orgField.sendKeys(org);
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            WebElement passwordField = inputFields.get(4);
            wait.until(ExpectedConditions.elementToBeClickable(passwordField)).click();
            passwordField.sendKeys(password);
            driver.pressKey(new KeyEvent(AndroidKey.ENTER));

            // Click checkbox
            WebElement checkbox = driver.findElement(By.className("android.widget.CheckBox"));
            if (!checkbox.getAttribute("checked").equals("true")) {
                checkbox.click();
                System.out.println("Agreed to terms.");
            }

            // Tap final "Sign up" button
            WebElement finalSignupBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//android.view.View[@content-desc='Sign up'])[2]")));
            finalSignupBtn.click();

            System.out.println("Signup form submitted.");
            Thread.sleep(5000);

        } catch (Exception e) {
            System.err.println("Signup error: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}
